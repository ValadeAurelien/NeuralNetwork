#ifndef LATTICE_INCLUDED
#define LATTICE_INCLUDED

#include "neuron.h"

#include <map> // equivalent du dictionnaire python
#include <vector>
#include <set>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

enum Weight_Map_t {FIRST, SECOND};

struct Neur_name_pt_t
{
  string name;
  Neuron * n_ptr;
};

class Reciprocical_link_t
{
  protected:
  Neuron * n_ptr1, *n_ptr2;
  
  public:
  Reciprocical_link_t(Neuron * _n_ptr1, Neuron * _n_ptr2) :
    n_ptr1 (_n_ptr1), n_ptr2(_n_ptr2){}
  bool operator<(const Reciprocical_link_t &link_2) const
  {
    if ((n_ptr1 == link_2.n_ptr1) & (n_ptr2 == link_2.n_ptr2))
      return true;
    if ((n_ptr1 == link_2.n_ptr2) & (n_ptr2 == link_2.n_ptr1))
      return true;
    else 
      return false;
  }
};

class Lattice
{
  protected :
  Weight_Map_t WEIGHTS_MAP = FIRST;
  const int max_lines_argfile = 1000,
            std_size = 20;
  int nb_neurons, nb_layers, max_neurons_per_layer;
  double learning_rate;
  map<string, Neuron*> neurons_ptrs;
  map<Neuron*, set<Neuron*>> backward_links, forward_links;
  vector<set<Neuron*>> layers;
  map<string, double> input, output, expected_values;
  map<Reciprocical_link_t, double> weights_first, weights_second;
  ifstream &argfile;

  static vector<string> split_string(string str, char const sep[]);
  static string simplify_string(string str);
  
  void add_to_layer(int layer, Neuron * neuron);
  void fill_output();

  void fill_input_neuron(Neuron* n_ptr);
  
  void switch_weights();
  void update_weight(Neuron* n_ptr1, Neuron* n_ptr2, double value);
  void update_weight_first(Neuron* n_ptr1, Neuron* n_ptr2, double value);
  void update_weight_second(Neuron* n_ptr1, Neuron* n_ptr2, double value);
  double get_weight(Neuron* n_ptr1, Neuron* n_ptr2);
  double get_weight_first(Neuron* n_ptr1, Neuron* n_ptr2);
  double get_weight_second(Neuron* n_ptr1, Neuron* n_ptr2);

  Neuron* get_neuron_ptr(const string& name);
  const set<Neuron*> & get_children(Neuron * n_ptr);
  const set<Neuron*> & get_parents(Neuron * n_ptr);
  double get_expected_value(string name);

  int get_min_neurons_per_layer();

  public :

  Lattice(ifstream& _argfile, double _learning_rate);
  ~Lattice();

  void init();

  void set_input(string name, double value);
  void set_expected_value(string name, double value);
  double get_output(string name);
  set<string> get_input_names();
  set<string> get_output_names();

  void evaluate();
  void update_weights();

  void represent(ofstream& outfile);
};
  

#endif
